-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 15, 2017 at 05:23 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `music_events`
--
CREATE DATABASE IF NOT EXISTS `music_events` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `music_events`;

-- --------------------------------------------------------

--
-- Table structure for table `Booking`
--

CREATE TABLE `Booking` (
  `Booking_ID` int(11) UNSIGNED NOT NULL,
  `Event_ID` int(11) UNSIGNED NOT NULL,
  `User_ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Booking`
--

INSERT INTO `Booking` (`Booking_ID`, `Event_ID`, `User_ID`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 1, 14),
(4, 1, 6),
(5, 1, 9),
(6, 2, 2),
(7, 2, 8),
(8, 2, 9),
(9, 7, 12),
(10, 7, 11),
(11, 7, 7),
(12, 8, 6),
(13, 10, 7),
(14, 12, 1),
(15, 15, 3),
(16, 14, 4),
(17, 11, 4),
(18, 3, 14),
(19, 5, 8),
(20, 4, 6),
(21, 6, 2),
(22, 9, 3),
(23, 8, 10),
(24, 8, 13),
(25, 9, 10),
(27, 8, 13),
(29, 12, 4),
(32, 10, 10),
(38, 9, 2),
(49, 8, 2),
(50, 7, 2),
(52, 2, 2),
(61, 15, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Event`
--

CREATE TABLE `Event` (
  `Event_ID` int(11) UNSIGNED NOT NULL,
  `Event_Name` varchar(256) NOT NULL,
  `Date` date NOT NULL,
  `Start_Time` time NOT NULL,
  `End_Time` time NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Max_Tickets` int(2) UNSIGNED NOT NULL,
  `Timestamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `Venue_ID` int(11) UNSIGNED NOT NULL,
  `Musician_ID` int(11) UNSIGNED NOT NULL,
  `User_ID` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Event`
--

INSERT INTO `Event` (`Event_ID`, `Event_Name`, `Date`, `Start_Time`, `End_Time`, `Description`, `Max_Tickets`, `Timestamp`, `Venue_ID`, `Musician_ID`, `User_ID`) VALUES
(1, 'Alison Moyet Tour 2017', '2017-11-01', '18:30:00', '21:30:00', 'Music presents Alison Moyet in Glasgow', 5, '2017-12-11 17:55:35', 1, 1, 1),
(2, 'Beth Hart Tour 2017', '2017-11-01', '18:30:00', '21:30:00', 'Music presents Beth Hart in Bath', 6, '2017-12-15 14:16:04', 2, 2, 4),
(3, 'Liam Gallagher Live 2017', '2017-11-01', '18:30:00', '21:30:00', 'Music presents Liam Gallagher in Newcastle Upon Tyne', 10, '2017-12-15 11:41:30', 3, 3, 5),
(4, 'Little Mix Live 2017', '2017-11-01', '18:30:00', '21:30:00', 'Music presents Little Mix in Liverpool', 9, '2017-12-11 17:57:09', 4, 4, 7),
(5, 'Chase and Status on Tour 2017', '2017-11-01', '19:00:00', '22:00:00', 'Music presents Chase and Status in Brixton', 10, '2017-12-11 17:57:26', 5, 5, 6),
(6, 'Harry Styles Live 2017', '2017-11-02', '18:30:00', '22:30:00', 'Music presents Harry Styles in Glasgow', 4, '2017-12-11 17:58:55', 6, 6, 3),
(7, 'The Travelling Band UK Tour 2017', '2017-11-02', '18:00:00', '21:00:00', 'Music presents The Travelling Band in Bristol', 11, '2017-12-15 12:27:38', 7, 7, 8),
(8, 'Leprous & Agent Fresco Live Wembley 2017', '2017-11-02', '18:30:00', '22:30:00', 'Music presents Leprous & Agent Fresco in London', 10, '2017-12-15 11:57:23', 8, 8, 9),
(9, 'Clean Bandit Live in O2 2017', '2017-11-02', '19:00:00', '22:30:00', 'Music presents Clean Bandit in London', 11, '2017-12-15 15:28:39', 9, 9, 2),
(10, 'Alison Moyet UK Tour Live 2017', '2017-11-02', '19:00:00', '22:30:00', 'Music presents Alison Moyet in Edinburgh', 6, '2017-12-11 18:14:08', 10, 1, 14),
(11, 'Blancmange Live 2017', '2018-02-01', '19:00:00', '22:00:00', 'Music presents Blancmange in Bristol', 8, '2017-12-15 14:34:25', 7, 10, 10),
(12, 'Paradise Lost Live at Wembley 2017', '2017-11-02', '18:00:00', '22:00:00', 'Music presents Paradise Lost in London', 10, '2017-12-11 18:17:10', 12, 11, 12),
(13, 'Forever Amy Live 2017', '2017-11-03', '19:30:00', '23:00:00', 'Music presents Forever Amy in Cardiff', 11, '2017-12-15 11:52:41', 13, 12, 11),
(14, 'Alexander O\'Neal Live 2017', '2017-11-03', '19:00:00', '23:30:00', 'Music presents Alexander O\'Neal in Liverpool', 6, '2017-12-11 18:21:29', 4, 13, 13),
(15, 'Little Mix Tour 2017', '2017-11-03', '18:30:00', '21:30:00', 'Music presents Little Mix in Newcastle Upon Tyne', 0, '2017-12-11 18:22:13', 3, 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Feedback`
--

CREATE TABLE `Feedback` (
  `Feedback_ID` int(11) UNSIGNED NOT NULL,
  `Event_ID` int(11) UNSIGNED NOT NULL,
  `User_ID` int(11) UNSIGNED NOT NULL,
  `rating` tinyint(1) NOT NULL,
  `comments` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Feedback`
--

INSERT INTO `Feedback` (`Feedback_ID`, `Event_ID`, `User_ID`, `rating`, `comments`) VALUES
(1, 1, 2, 3, 'great concert!'),
(2, 1, 3, 4, 'loved it'),
(3, 1, 14, 5, 'Amazing! I absolutely loved it'),
(4, 1, 6, 4, NULL),
(5, 1, 9, 4, 'Could have been better'),
(6, 2, 2, 4, NULL),
(7, 2, 8, 5, 'stupendous'),
(8, 2, 9, 5, 'wonderful'),
(9, 7, 12, 5, 'terrific'),
(10, 7, 11, 3, 'good'),
(11, 7, 7, 2, 'Parking was too full but the concert was okay'),
(12, 8, 6, 4, 'jolly good show'),
(13, 10, 7, 5, 'definitely will be coming back'),
(14, 12, 1, 3, 'its good'),
(15, 15, 3, 2, 'just okay, not worth the money'),
(16, 14, 4, 4, 'my children had a good time'),
(17, 11, 4, 4, NULL),
(18, 3, 14, 3, NULL),
(19, 5, 8, 4, NULL),
(20, 4, 6, 5, NULL),
(21, 6, 2, 4, NULL),
(22, 9, 3, 4, NULL),
(23, 8, 10, 4, NULL),
(24, 2, 9, 4, 'Nice Concert!');

-- --------------------------------------------------------

--
-- Table structure for table `Genre`
--

CREATE TABLE `Genre` (
  `Genre_ID` int(10) UNSIGNED NOT NULL,
  `Genre_Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Genre`
--

INSERT INTO `Genre` (`Genre_ID`, `Genre_Name`) VALUES
(1, 'Alternative/ Indie'),
(2, 'Rock/Pop'),
(3, 'Club/Dance'),
(4, 'Country/Folk'),
(5, 'Hard Rock/Metal'),
(6, 'Jazz/Blues'),
(7, 'Urban Soul');

-- --------------------------------------------------------

--
-- Table structure for table `Musician`
--

CREATE TABLE `Musician` (
  `Musician_ID` int(11) UNSIGNED NOT NULL,
  `Musician_Name` varchar(255) DEFAULT NULL,
  `Biography` text NOT NULL,
  `Genre_ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Musician`
--

INSERT INTO `Musician` (`Musician_ID`, `Musician_Name`, `Biography`, `Genre_ID`) VALUES
(1, 'Alison Moyet', 'English singer, songwriter and performer born in Essex.', 1),
(2, 'Beth Hart', 'American singer, songwriter and musician borin in Los Angeles. She has eight albums.', 2),
(3, 'Liam Gallagher', 'English singer, songwriter and performer born in Manchester. He has one album and released various singles.', 2),
(4, 'Little Mix', 'British girl group formed in the eight seies of UK Xfactor. They have released four albums. ', 2),
(5, 'Chase and Status', 'English drum and bass production band. They have collaborated with famous artists including Tinie Tempah and Rihanna', 3),
(6, 'Harry Styles', 'English singer, songwritet and actor. He is a former member of One Direction band. He recently released a self-titled alum.', 2),
(7, 'The Travelling Band', 'English folk band formed in 2006. They have released three albums since the member came together.', 4),
(8, 'Leprous & Agent Fresco', 'Norwegian and Icelandic metallers performing in the heart of England.', 5),
(9, 'Clean Bandit', 'British Electronic music group fromed in 2008. They have released one album and won various awards for their music.', 2),
(10, 'Blancmange', 'English band formed in 1979. They have released a number of compiltion and studio albums', 1),
(11, 'Paradise Lost', 'English gothic metal band formed in 1988. They have released 15 albums since their formation and the last album was released late this year.', 5),
(12, 'Forever Amy ', 'This band is dedicated to the celebration of Amy Winehouse and her music.', 6),
(13, 'Alexander O\'Neal', 'American R&B singer, songwriter and arranger. His first album was self-titled and he has released nine more albums during his career', 7);

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `User_ID` int(11) UNSIGNED NOT NULL,
  `First_Name` varchar(255) DEFAULT NULL,
  `Last_Name` varchar(255) DEFAULT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  `Password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`User_ID`, `First_Name`, `Last_Name`, `email_address`, `Password`) VALUES
(1, 'Sam ', 'Jones', 'samjones@yahoo.com', 'sammy123'),
(2, 'Mike', 'Stone', 'mikestones@gmail.com', 'miketherapper'),
(3, 'Alan', 'Banks', 'alanbanks@yahoo.com', 'alanthehipster'),
(4, 'Annie', 'Cabbot', 'anniecabbot@yahoo.com', 'caban345'),
(5, 'Carmen', 'Petri', 'carmenpetri@yahoo.com', 'beauty123!'),
(6, 'Gareth', 'Lambert', 'garethlambert@yahoo.com', 'baleiscool3'),
(7, 'Hermionie', 'Granger', 'hermioniegranger@yahoo.com', 'mugglesarebest'),
(8, 'Harry', 'Potter', 'harrypotter@yahoo.com', 'longlivegryf'),
(9, 'Ron', 'Weasley', 'ronweasley@yahoo.com', 'gingerisbest135'),
(10, 'Fred', 'Weasley', 'fredweasley@yahoo.com', 'fredisinbed19'),
(11, 'George', 'Weasley', 'georgeweasley@yahoo.com', 'weaslethemeasle'),
(12, 'Ginny', 'Weasley', 'ginnyweasley@yahoo.com', 'GandH4ever'),
(13, 'Cedric', 'Diggory', 'cedricdiggory@yahoo.com', 'ikicikass123'),
(14, 'Luna', 'Lovegood', 'lunalovegood@yahoo.com', 'Loveisgood2'),
(15, 'Tom', 'Riddle', 'tomriddle@yahoo.com', 'Voldemort4'),
(16, 'Roy', 'Banks', 'roybanks@yahoo.com', 'bankis4money'),
(17, 'John ', 'Doe', 'John.doe@yahoo.com', 'unknown23'),
(18, 'Jane', 'Doe', 'Jane.Doe@yahoo.com', 'reknown34'),
(19, 'Tim', 'Middelton', 'timmiddelton@yahoo.fr', 'middel'),
(24, 'john', 'blake', 'johnblake@ucl.ac.uk', 'john');

-- --------------------------------------------------------

--
-- Table structure for table `Venue`
--

CREATE TABLE `Venue` (
  `Venue_ID` int(11) UNSIGNED NOT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Region` varchar(255) DEFAULT NULL,
  `Postcode` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Venue`
--

INSERT INTO `Venue` (`Venue_ID`, `Location`, `Region`, `Postcode`) VALUES
(1, 'Glasgow Royal Concert Hall', 'Glasgow', 'G2 3NY'),
(2, 'Bath Forum', 'Bath', 'BA1 1UG'),
(3, 'Metro radio Arena', 'Newcastle Upon Tyne', 'NE4 7NA'),
(4, 'Liverpool Echo Arena', 'Liverpool', 'L3 4FP'),
(5, 'O2 Academy Brixton', 'Brixton', 'SW9 9SL'),
(6, 'SEC Armdaillo', 'Glasgow', 'G3 8YW'),
(7, 'Thekla', 'Bristol', 'BS1 4RB'),
(8, 'The Dome', 'London', 'NW5 1HL'),
(9, 'Eventim Apollo', 'London', 'W6 9QH'),
(10, 'Usher Hall', 'Edinburgh', 'EH1 2EA'),
(11, 'The Fleece', 'Bristol', 'BS1 6JJ'),
(12, 'Electric Ballroom', 'London', 'NW1 8QP'),
(13, 'Tramshed', 'Cardiff', ' CF11 6Q'),
(14, 'Crewe Lyceum Theatre', 'Crewe', 'CW1 2DA'),
(15, 'Metro radio Arena', 'Newcastle Upon Tyne', 'NE4 7NA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Booking`
--
ALTER TABLE `Booking`
  ADD PRIMARY KEY (`Booking_ID`),
  ADD KEY `Event_ID` (`Event_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Event`
--
ALTER TABLE `Event`
  ADD PRIMARY KEY (`Event_ID`),
  ADD KEY `Venue_ID` (`Venue_ID`),
  ADD KEY `Musician_ID` (`Musician_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Feedback`
--
ALTER TABLE `Feedback`
  ADD PRIMARY KEY (`Feedback_ID`),
  ADD KEY `Event_ID` (`Event_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Genre`
--
ALTER TABLE `Genre`
  ADD PRIMARY KEY (`Genre_ID`);

--
-- Indexes for table `Musician`
--
ALTER TABLE `Musician`
  ADD PRIMARY KEY (`Musician_ID`),
  ADD KEY `Genre_ID` (`Genre_ID`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `email_address` (`email_address`);

--
-- Indexes for table `Venue`
--
ALTER TABLE `Venue`
  ADD PRIMARY KEY (`Venue_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Booking`
--
ALTER TABLE `Booking`
  MODIFY `Booking_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `Event`
--
ALTER TABLE `Event`
  MODIFY `Event_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `Feedback`
--
ALTER TABLE `Feedback`
  MODIFY `Feedback_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `Genre`
--
ALTER TABLE `Genre`
  MODIFY `Genre_ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Musician`
--
ALTER TABLE `Musician`
  MODIFY `Musician_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `User_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `Venue`
--
ALTER TABLE `Venue`
  MODIFY `Venue_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Booking`
--
ALTER TABLE `Booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`Event_ID`) REFERENCES `Event` (`Event_ID`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `User` (`User_ID`);

--
-- Constraints for table `Event`
--
ALTER TABLE `Event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `User` (`User_ID`),
  ADD CONSTRAINT `event_ibfk_2` FOREIGN KEY (`Venue_ID`) REFERENCES `Venue` (`Venue_ID`),
  ADD CONSTRAINT `event_ibfk_3` FOREIGN KEY (`Musician_ID`) REFERENCES `Musician` (`Musician_ID`);

--
-- Constraints for table `Feedback`
--
ALTER TABLE `Feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`Event_ID`) REFERENCES `Event` (`Event_ID`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `User` (`User_ID`);

--
-- Constraints for table `Musician`
--
ALTER TABLE `Musician`
  ADD CONSTRAINT `musician_ibfk_1` FOREIGN KEY (`Genre_ID`) REFERENCES `Genre` (`Genre_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
